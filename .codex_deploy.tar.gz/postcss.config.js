module.exports = {
    plugins: {},
};
