/* eslint-env browser */

import RFB from "/vendor/novnc/core/rfb.js";

const elements = {
    activeProxy: document.querySelector("#activeProxy"),
    addressForm: document.querySelector("#addressForm"),
    addressGo: document.querySelector("#addressForm button"),
    addressInput: document.querySelector("#addressInput"),
    applyToken: document.querySelector("#applyToken"),
    browserActions: [...document.querySelectorAll("[data-browser-action]")],
    browserOverlay: document.querySelector("#browserOverlay"),
    browserWorkspace: document.querySelector("#browserWorkspace"),
    checkEgress: document.querySelector("#checkEgress"),
    controlToken: document.querySelector("#controlToken"),
    egressIp: document.querySelector("#egressIp"),
    fullscreenButton: document.querySelector("#fullscreenButton"),
    overlayDetail: document.querySelector("#overlayDetail"),
    overlayTitle: document.querySelector("#overlayTitle"),
    proxyEnabled: document.querySelector("#proxyEnabled"),
    proxyFields: document.querySelector("#proxyFields"),
    proxyHost: document.querySelector("#proxyHost"),
    proxyPassword: document.querySelector("#proxyPassword"),
    proxyPort: document.querySelector("#proxyPort"),
    proxyUsername: document.querySelector("#proxyUsername"),
    reconnectVnc: document.querySelector("#reconnectVnc"),
    resolution: document.querySelector("#resolution"),
    routeLine: document.querySelector("#routeLine"),
    sessionForm: document.querySelector("#sessionForm"),
    startButton: document.querySelector("#startButton"),
    startButtonText: document.querySelector("#startButton span"),
    startUrl: document.querySelector("#startUrl"),
    statusBadge: document.querySelector("#statusBadge"),
    statusText: document.querySelector("#statusText"),
    stopButton: document.querySelector("#stopButton"),
    toast: document.querySelector("#toast"),
    togglePassword: document.querySelector("#togglePassword"),
    uptime: document.querySelector("#uptime"),
    vncFrame: document.querySelector("#vncFrame"),
    vncSurface: document.querySelector("#vncSurface"),
};

const stateLabels = {
    error: "异常",
    idle: "空闲",
    running: "运行中",
    starting: "启动中",
    stopping: "停止中",
};

let sessionStatus = { state: "idle" };
let rfb = null;
let connectInProgress = false;
let toastTimer = null;
let reconnectTimer = null;

function controlToken() {
    return elements.controlToken.value.trim();
}

async function api(path, options = {}) {
    const headers = new Headers(options.headers || {});
    if (controlToken()) headers.set("X-Control-Token", controlToken());
    if (options.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
    const response = await fetch(path, { ...options, headers });
    let payload = {};
    try {
        payload = await response.json();
    } catch {
        payload = {};
    }
    if (!response.ok) {
        const error = new Error(payload.error || `请求失败 (${response.status})`);
        error.status = response.status;
        error.payload = payload;
        throw error;
    }
    return payload;
}

function showToast(message, type = "info") {
    clearTimeout(toastTimer);
    elements.toast.textContent = message;
    elements.toast.classList.toggle("is-error", type === "error");
    elements.toast.classList.add("is-visible");
    toastTimer = setTimeout(() => elements.toast.classList.remove("is-visible"), 3_600);
}

function selectedProtocol() {
    return document.querySelector('input[name="proxyProtocol"]:checked').value;
}

function viewportValue() {
    if (elements.resolution.value !== "auto") {
        const [width, height] = elements.resolution.value.split("x").map(Number);
        return { height, width };
    }
    const rect = elements.vncFrame.getBoundingClientRect();
    return {
        height: Math.max(600, Math.floor(rect.height || 900)),
        width: Math.max(390, Math.floor(rect.width || 1440)),
    };
}

function sessionPayload() {
    const proxyEnabled = elements.proxyEnabled.checked;
    const protocol = selectedProtocol();
    const host = elements.proxyHost.value.trim();
    const port = elements.proxyPort.value.trim();
    return {
        proxy: {
            enabled: proxyEnabled,
            password: elements.proxyPassword.value,
            server: proxyEnabled ? `${protocol}://${host}:${port}` : "",
            username: elements.proxyUsername.value.trim(),
        },
        startUrl: elements.startUrl.value.trim(),
        viewport: viewportValue(),
    };
}

function persistSettings() {
    const settings = {
        proxyEnabled: elements.proxyEnabled.checked,
        proxyHost: elements.proxyHost.value.trim(),
        proxyPort: elements.proxyPort.value.trim(),
        proxyProtocol: selectedProtocol(),
        resolution: elements.resolution.value,
        startUrl: elements.startUrl.value.trim(),
    };
    localStorage.setItem("browserRelaySettings", JSON.stringify(settings));
    sessionStorage.setItem("browserRelayToken", controlToken());
}

function restoreSettings() {
    elements.controlToken.value = sessionStorage.getItem("browserRelayToken") || "";
    try {
        const settings = JSON.parse(localStorage.getItem("browserRelaySettings") || "{}");
        if (typeof settings.proxyEnabled === "boolean") elements.proxyEnabled.checked = settings.proxyEnabled;
        if (settings.proxyHost) elements.proxyHost.value = settings.proxyHost;
        if (settings.proxyPort) elements.proxyPort.value = settings.proxyPort;
        if (settings.proxyProtocol) {
            const option = document.querySelector(
                `input[name="proxyProtocol"][value="${CSS.escape(settings.proxyProtocol)}"]`
            );
            if (option) option.checked = true;
        }
        if (settings.resolution) elements.resolution.value = settings.resolution;
        if (settings.startUrl) {
            elements.startUrl.value = settings.startUrl;
            elements.addressInput.value = settings.startUrl;
        }
    } catch {
        localStorage.removeItem("browserRelaySettings");
    }
    updateProxyFields();
}

function updateProxyFields() {
    elements.proxyFields.classList.toggle("is-disabled", !elements.proxyEnabled.checked);
    for (const input of elements.proxyFields.querySelectorAll("input")) {
        input.disabled = !elements.proxyEnabled.checked;
    }
    const defaults = { http: "8080", https: "443", socks5: "1080" };
    if (!elements.proxyPort.dataset.edited) elements.proxyPort.value = defaults[selectedProtocol()];
}

function setOverlay(title, detail = "", busy = false) {
    elements.overlayTitle.textContent = title;
    elements.overlayDetail.textContent = detail;
    elements.browserOverlay.classList.remove("is-hidden");
    elements.browserOverlay.classList.toggle("is-busy", busy);
}

function formatDuration(startedAt) {
    if (!startedAt) return "00:00:00";
    const seconds = Math.max(0, Math.floor((Date.now() - new Date(startedAt).getTime()) / 1000));
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return [hours, minutes, seconds % 60].map(value => String(value).padStart(2, "0")).join(":");
}

function updateStatusUI(nextStatus) {
    sessionStatus = nextStatus;
    const currentState = nextStatus.state || "idle";
    elements.statusBadge.className = `status-badge is-${currentState}`;
    elements.statusText.textContent = stateLabels[currentState] || currentState;
    elements.routeLine.classList.toggle("is-active", currentState === "running");
    elements.activeProxy.textContent = nextStatus.proxy || "直连";
    elements.activeProxy.title = nextStatus.proxy || "直连";
    elements.egressIp.textContent = nextStatus.egressIp || "未检测";
    elements.uptime.textContent = formatDuration(nextStatus.startedAt);

    const running = currentState === "running";
    const busy = nextStatus.transitionInProgress || new Set(["starting", "stopping"]).has(currentState);
    elements.startButton.disabled = busy;
    elements.startButtonText.textContent = running ? "重启并应用" : "启动会话";
    elements.stopButton.disabled = !running || busy;
    elements.checkEgress.disabled = !running || busy;
    elements.reconnectVnc.disabled = !running || busy;
    elements.addressInput.disabled = !running || busy;
    elements.addressGo.disabled = !running || busy;
    elements.browserActions.forEach(button => {
        button.disabled = !running || busy;
    });

    if (nextStatus.startUrl && running && document.activeElement !== elements.addressInput) {
        elements.addressInput.value = nextStatus.startUrl;
    }

    if (currentState === "idle") setOverlay("会话未启动");
    else if (currentState === "starting") setOverlay("正在启动远程浏览器", "", true);
    else if (currentState === "stopping") setOverlay("正在关闭会话", "", true);
    else if (currentState === "error") setOverlay("会话异常", nextStatus.error || "浏览器进程已结束");
    else if (running && !rfb) setOverlay("正在连接远程画面", "", true);
}

function disconnectVnc() {
    clearTimeout(reconnectTimer);
    reconnectTimer = null;
    if (rfb) {
        const current = rfb;
        rfb = null;
        try {
            current.disconnect();
        } catch {
            // The transport may already be closed.
        }
    }
    elements.vncSurface.replaceChildren();
}

async function connectVnc() {
    if (connectInProgress || sessionStatus.state !== "running") return;
    connectInProgress = true;
    disconnectVnc();
    setOverlay("正在连接远程画面", "", true);

    try {
        const { ticket } = await api("/api/vnc-ticket", { method: "POST" });
        const protocol = location.protocol === "https:" ? "wss" : "ws";
        const wsUrl = `${protocol}://${location.host}/vnc?ticket=${encodeURIComponent(ticket)}`;
        const client = new RFB(elements.vncSurface, wsUrl, { shared: true });
        rfb = client;
        client.scaleViewport = true;
        client.resizeSession = false;
        client.focusOnClick = true;
        client.addEventListener("connect", () => {
            if (rfb !== client) return;
            elements.browserOverlay.classList.add("is-hidden");
            elements.browserOverlay.classList.remove("is-busy");
        });
        client.addEventListener("disconnect", event => {
            if (rfb !== client) return;
            rfb = null;
            const reason = event.detail?.reason || "远程画面连接已结束";
            setOverlay("画面连接已断开", reason);
            if (sessionStatus.state === "running") {
                reconnectTimer = setTimeout(() => void connectVnc(), 1_500);
            }
        });
        client.addEventListener("securityfailure", () => {
            showToast("VNC 握手校验失败。", "error");
        });
    } catch (error) {
        setOverlay("画面连接失败", error.message);
        showToast(error.message, "error");
    } finally {
        connectInProgress = false;
    }
}

async function refreshStatus({ connect = false, silent = false } = {}) {
    try {
        const nextStatus = await api("/api/session");
        const wasRunning = sessionStatus.state === "running";
        updateStatusUI(nextStatus);
        if (nextStatus.state === "running" && (connect || !wasRunning) && !rfb) await connectVnc();
        if (nextStatus.state !== "running" && rfb) disconnectVnc();
    } catch (error) {
        if (!silent) showToast(error.message, "error");
        if (error.status === 401) setOverlay("管理令牌校验失败");
    }
}

elements.proxyEnabled.addEventListener("change", () => {
    updateProxyFields();
    persistSettings();
});

document.querySelectorAll('input[name="proxyProtocol"]').forEach(input => {
    input.addEventListener("change", () => {
        elements.proxyPort.dataset.edited = "";
        updateProxyFields();
        persistSettings();
    });
});

elements.proxyPort.addEventListener("input", () => {
    elements.proxyPort.dataset.edited = "true";
});

elements.sessionForm.addEventListener("submit", async event => {
    event.preventDefault();
    persistSettings();
    disconnectVnc();
    updateStatusUI({ ...sessionStatus, state: "starting", transitionInProgress: true });
    try {
        const nextStatus = await api("/api/session", {
            body: JSON.stringify(sessionPayload()),
            method: "POST",
        });
        updateStatusUI(nextStatus);
        await connectVnc();
        showToast(nextStatus.proxy ? `会话已通过 ${nextStatus.proxy} 启动。` : "直连会话已启动。");
    } catch (error) {
        const nextStatus = error.payload?.status || { error: error.message, state: "error" };
        updateStatusUI(nextStatus);
        showToast(error.message, "error");
    }
});

elements.stopButton.addEventListener("click", async () => {
    updateStatusUI({ ...sessionStatus, state: "stopping", transitionInProgress: true });
    disconnectVnc();
    try {
        const nextStatus = await api("/api/session", { method: "DELETE" });
        updateStatusUI(nextStatus);
        showToast("会话已停止。");
    } catch (error) {
        showToast(error.message, "error");
        await refreshStatus({ silent: true });
    }
});

elements.applyToken.addEventListener("click", async () => {
    sessionStorage.setItem("browserRelayToken", controlToken());
    await refreshStatus({ connect: true });
});

elements.togglePassword.addEventListener("click", () => {
    const showing = elements.proxyPassword.type === "text";
    elements.proxyPassword.type = showing ? "password" : "text";
    elements.togglePassword.title = showing ? "显示密码" : "隐藏密码";
    const icon = elements.togglePassword.querySelector("svg");
    if (icon) icon.style.opacity = showing ? "1" : "0.65";
});

elements.checkEgress.addEventListener("click", async () => {
    elements.checkEgress.disabled = true;
    try {
        const result = await api("/api/session/egress");
        elements.egressIp.textContent = result.ip || "未知";
        sessionStatus.egressIp = result.ip || null;
        showToast(`当前出口 IP：${result.ip}`);
    } catch (error) {
        showToast(error.message, "error");
    } finally {
        elements.checkEgress.disabled = sessionStatus.state !== "running";
    }
});

elements.addressForm.addEventListener("submit", async event => {
    event.preventDefault();
    try {
        const result = await api("/api/session/navigate", {
            body: JSON.stringify({ url: elements.addressInput.value.trim() }),
            method: "POST",
        });
        elements.addressInput.value = result.url;
    } catch (error) {
        showToast(error.message, "error");
    }
});

elements.browserActions.forEach(button => {
    button.addEventListener("click", async () => {
        try {
            const result = await api("/api/session/action", {
                body: JSON.stringify({ action: button.dataset.browserAction }),
                method: "POST",
            });
            if (result.url) elements.addressInput.value = result.url;
        } catch (error) {
            showToast(error.message, "error");
        }
    });
});

elements.reconnectVnc.addEventListener("click", () => void connectVnc());

elements.fullscreenButton.addEventListener("click", async () => {
    try {
        if (document.fullscreenElement) await document.exitFullscreen();
        else await elements.browserWorkspace.requestFullscreen();
    } catch (error) {
        showToast(error.message, "error");
    }
});

window.addEventListener("beforeunload", disconnectVnc);

restoreSettings();
window.lucide?.createIcons({ attrs: { "stroke-width": 1.8 } });
updateStatusUI(sessionStatus);
void refreshStatus({ connect: true, silent: true });

setInterval(() => {
    elements.uptime.textContent = formatDuration(sessionStatus.startedAt);
}, 1_000);

setInterval(() => void refreshStatus({ silent: true }), 3_000);
