# Camoufox VNC Console

独立的单会话远程浏览器镜像，只包含 Camoufox、Playwright、Xvfb、x11vnc、websockify 和管理页面。

## 启动

```bash
cd browser-vnc
docker compose up --build -d
```

打开 `http://localhost:7861`。在左侧填写起始网址和本次会话使用的代理，然后点击“启动会话”。

停止：

```bash
docker compose down
```

## 配置

| 环境变量           | 默认值                    | 用途                                      |
| ------------------ | ------------------------- | ----------------------------------------- |
| `BROWSER_VNC_PORT` | `7861`                    | 宿主机管理页面端口                        |
| `CONTROL_TOKEN`    | 空                        | 管理 API 令牌；设置后在页面中填写相同令牌 |
| `START_URL`        | `https://www.google.com/` | 默认起始网址                              |
| `TZ`               | `Asia/Shanghai`           | 容器时区                                  |
| `CAMOUFOX_VERSION` | `135.0.1-beta.24`         | 构建时下载的 Camoufox 版本                |
| `NODE_IMAGE`       | `node:24-slim`            | 可替换的 Node.js 基础镜像                 |

代理按会话传入 Playwright 的浏览器启动参数和 BrowserContext。支持 `HTTP`、`HTTPS`、`SOCKS5`，用户名和密码不会出现在状态接口及服务日志中。修改代理后重启会话生效。

容器仅映射管理端口。VNC `5901` 和 websockify `6080` 绑定在容器回环地址，浏览器画面通过带短期一次性票据的 `/vnc` WebSocket 提供。
