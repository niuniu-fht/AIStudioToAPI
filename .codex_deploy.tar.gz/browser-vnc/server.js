"use strict";

const crypto = require("crypto");
const http = require("http");
const net = require("net");
const path = require("path");
const { spawn } = require("child_process");
const express = require("express");
const { firefox } = require("playwright-core");

const PORT = Number.parseInt(process.env.PORT || "7860", 10);
const CONTROL_TOKEN = String(process.env.CONTROL_TOKEN || "").trim();
const CAMOUFOX_EXECUTABLE_PATH = process.env.CAMOUFOX_EXECUTABLE_PATH || "/opt/camoufox/camoufox";
const DEFAULT_START_URL = process.env.START_URL || "https://www.google.com/";
const DISPLAY = ":99";
const VNC_PORT = 5901;
const WEBSOCKIFY_PORT = 6080;
const TICKET_TTL_MS = 30_000;
const allowedProxyProtocols = new Set(["http:", "https:", "socks5:"]);

const app = express();
const server = http.createServer(app);
const vncTickets = new Map();

let runtime = null;
let transitionInProgress = false;
let status = {
    egressIp: null,
    error: null,
    navigationError: null,
    proxy: null,
    startedAt: null,
    startUrl: DEFAULT_START_URL,
    state: "idle",
    viewport: null,
};

app.disable("x-powered-by");
app.use(express.json({ limit: "32kb" }));

function log(message) {
    process.stdout.write(`[browser-vnc] ${new Date().toISOString()} ${message}\n`);
}

function tokenMatches(candidate) {
    if (!CONTROL_TOKEN) return true;
    const supplied = Buffer.from(String(candidate || ""));
    const expected = Buffer.from(CONTROL_TOKEN);
    return supplied.length === expected.length && crypto.timingSafeEqual(supplied, expected);
}

function authorizeHttp(req, res, next) {
    const bearer = req.headers.authorization?.startsWith("Bearer ")
        ? req.headers.authorization.slice("Bearer ".length)
        : "";
    if (tokenMatches(req.headers["x-control-token"] || bearer)) return next();
    return res.status(401).json({ error: "管理令牌错误。" });
}

function publicStatus() {
    return {
        ...status,
        controlTokenRequired: Boolean(CONTROL_TOKEN),
        transitionInProgress,
    };
}

function normalizeStartUrl(value) {
    const raw = String(value || DEFAULT_START_URL).trim();
    const parsed = new URL(raw);
    if (!new Set(["http:", "https:"]).has(parsed.protocol)) {
        throw new Error("起始网址仅支持 HTTP 或 HTTPS。请填写完整网址。");
    }
    return parsed.toString();
}

function normalizeViewport(value = {}) {
    const width = Math.min(2560, Math.max(390, Number.parseInt(value.width, 10) || 1440));
    const height = Math.min(1440, Math.max(600, Number.parseInt(value.height, 10) || 900));
    return { height, width };
}

function normalizeProxy(value = {}) {
    if (!value.enabled) return null;

    let rawServer = String(value.server || "").trim();
    if (!rawServer) throw new Error("启用代理后需要填写代理服务器。");
    if (!rawServer.includes("://")) rawServer = `http://${rawServer}`;

    const parsed = new URL(rawServer);
    if (!allowedProxyProtocols.has(parsed.protocol)) {
        throw new Error("代理协议支持 HTTP、HTTPS 和 SOCKS5。");
    }
    if (!parsed.hostname) throw new Error("代理服务器地址不完整。");
    if ((parsed.pathname && parsed.pathname !== "/") || parsed.search || parsed.hash) {
        throw new Error("代理地址只填写协议、主机和端口，不包含路径或查询参数。");
    }

    const defaultPorts = { "http:": "80", "https:": "443", "socks5:": "1080" };
    const port = parsed.port || defaultPorts[parsed.protocol];
    const hostname =
        parsed.hostname.includes(":") && !parsed.hostname.startsWith("[") ? `[${parsed.hostname}]` : parsed.hostname;
    const serverAddress = `${parsed.protocol}//${hostname}:${port}`;
    const username = String(value.username || decodeURIComponent(parsed.username || "")).trim();
    const password = String(value.password || decodeURIComponent(parsed.password || ""));
    const config = { server: serverAddress };
    if (username) config.username = username;
    if (password) config.password = password;

    return {
        config,
        display: serverAddress,
    };
}

function spawnManaged(command, args, options = {}) {
    const child = spawn(command, args, {
        env: { ...process.env, ...options.env },
        stdio: ["ignore", "pipe", "pipe"],
    });
    child.stdout.on("data", data => {
        const output = data.toString().trim();
        if (output) log(`${command}: ${output}`);
    });
    child.stderr.on("data", data => {
        const output = data.toString().trim();
        if (output && !output.includes("The VNC desktop is:")) log(`${command}: ${output}`);
    });
    child.on("error", error => log(`${command} 启动错误: ${error.message}`));
    return child;
}

function waitForPort(port, timeoutMs = 15_000) {
    const startedAt = Date.now();
    return new Promise((resolve, reject) => {
        const attempt = () => {
            const socket = net.createConnection({ host: "127.0.0.1", port });
            socket.once("connect", () => {
                socket.destroy();
                resolve();
            });
            socket.once("error", () => {
                socket.destroy();
                if (Date.now() - startedAt >= timeoutMs) {
                    reject(new Error(`等待内部端口 ${port} 超时。`));
                    return;
                }
                setTimeout(attempt, 120);
            });
        };
        attempt();
    });
}

async function terminateProcess(child) {
    if (!child || child.exitCode !== null || child.signalCode) return;
    const exited = new Promise(resolve => child.once("exit", resolve));
    child.kill("SIGTERM");
    await Promise.race([exited, new Promise(resolve => setTimeout(resolve, 1_200))]);
    if (child.exitCode === null && !child.signalCode) child.kill("SIGKILL");
}

async function stopRuntime(reason = "manual") {
    const current = runtime;
    runtime = null;
    if (!current) {
        status = { ...status, egressIp: null, error: null, startedAt: null, state: "idle", viewport: null };
        return;
    }

    status = { ...status, state: "stopping" };
    log(`结束浏览器会话: ${reason}`);
    await Promise.allSettled([current.page?.close(), current.context?.close(), current.browser?.close()]);
    await Promise.all([
        terminateProcess(current.websockify),
        terminateProcess(current.x11vnc),
        terminateProcess(current.xvfb),
    ]);
    status = {
        ...status,
        egressIp: null,
        error: null,
        navigationError: null,
        proxy: null,
        startedAt: null,
        state: "idle",
        viewport: null,
    };
}

async function startRuntime(body) {
    await stopRuntime("replace_session");

    const startUrl = normalizeStartUrl(body.startUrl);
    const viewport = normalizeViewport(body.viewport);
    const proxy = normalizeProxy(body.proxy);
    const screen = `${viewport.width}x${viewport.height}x24`;

    status = {
        egressIp: null,
        error: null,
        navigationError: null,
        proxy: proxy?.display || null,
        startedAt: null,
        startUrl,
        state: "starting",
        viewport,
    };

    const session = {};
    runtime = session;

    try {
        session.xvfb = spawnManaged("Xvfb", [DISPLAY, "-screen", "0", screen, "+extension", "RANDR"]);
        await new Promise(resolve => setTimeout(resolve, 500));

        session.x11vnc = spawnManaged("x11vnc", [
            "-display",
            DISPLAY,
            "-rfbport",
            String(VNC_PORT),
            "-localhost",
            "-forever",
            "-nopw",
            "-shared",
            "-quiet",
            "-repeat",
        ]);
        await waitForPort(VNC_PORT);

        session.websockify = spawnManaged("websockify", [`127.0.0.1:${WEBSOCKIFY_PORT}`, `127.0.0.1:${VNC_PORT}`]);
        await waitForPort(WEBSOCKIFY_PORT);

        const launchOptions = {
            env: { ...process.env, DISPLAY },
            executablePath: CAMOUFOX_EXECUTABLE_PATH,
            firefoxUserPrefs: {
                "network.proxy.socks_remote_dns": true,
                "network.trr.mode": 5,
                "network.trr.uri": "",
            },
            headless: false,
        };
        if (proxy) launchOptions.proxy = proxy.config;

        session.browser = await firefox.launch(launchOptions);
        session.context = await session.browser.newContext({
            screen: viewport,
            viewport,
            ...(proxy ? { proxy: proxy.config } : {}),
        });
        session.page = await session.context.newPage();

        session.browser.once("disconnected", () => {
            if (runtime === session && status.state === "running") {
                status = { ...status, error: "远程浏览器进程已关闭。", state: "error" };
            }
        });

        try {
            await session.page.goto(startUrl, { timeout: 45_000, waitUntil: "domcontentloaded" });
        } catch (error) {
            status.navigationError = error.message;
            log(`起始页面加载提示: ${error.message}`);
        }

        status = {
            ...status,
            startedAt: new Date().toISOString(),
            state: "running",
        };
        log(`浏览器会话已启动，代理: ${proxy?.display || "直连"}`);
    } catch (error) {
        status = { ...status, error: error.message, state: "error" };
        await stopRuntime("startup_error");
        status = { ...status, error: error.message, state: "error" };
        throw error;
    }
}

function activePage() {
    if (!runtime?.context) throw new Error("浏览器会话尚未运行。");
    const pages = runtime.context.pages().filter(page => !page.isClosed());
    if (pages.length === 0) throw new Error("当前没有可操作的浏览器页面。");
    return pages.at(-1);
}

function requireRunning(req, res, next) {
    if (status.state !== "running" || !runtime?.context) {
        return res.status(409).json({ error: "请先启动浏览器会话。" });
    }
    return next();
}

app.get("/health", (req, res) => {
    res.json({ ok: true, state: status.state });
});

app.use("/api", authorizeHttp);

app.get("/api/session", (req, res) => {
    res.json(publicStatus());
});

app.post("/api/session", async (req, res) => {
    if (transitionInProgress) return res.status(409).json({ error: "会话正在切换，请稍后重试。" });
    transitionInProgress = true;
    try {
        await startRuntime(req.body || {});
        return res.status(201).json(publicStatus());
    } catch (error) {
        return res.status(400).json({ error: error.message, status: publicStatus() });
    } finally {
        transitionInProgress = false;
    }
});

app.delete("/api/session", async (req, res) => {
    if (transitionInProgress) return res.status(409).json({ error: "会话正在切换，请稍后重试。" });
    transitionInProgress = true;
    try {
        await stopRuntime("api_request");
        return res.json(publicStatus());
    } finally {
        transitionInProgress = false;
    }
});

app.post("/api/session/navigate", requireRunning, async (req, res) => {
    try {
        const url = normalizeStartUrl(req.body?.url);
        const page = activePage();
        await page.goto(url, { timeout: 45_000, waitUntil: "domcontentloaded" });
        status = { ...status, navigationError: null, startUrl: url };
        return res.json({ ok: true, url: page.url() });
    } catch (error) {
        status = { ...status, navigationError: error.message };
        return res.status(400).json({ error: error.message });
    }
});

app.post("/api/session/action", requireRunning, async (req, res) => {
    const action = String(req.body?.action || "");
    const page = activePage();
    try {
        if (action === "back") await page.goBack({ timeout: 30_000, waitUntil: "domcontentloaded" });
        else if (action === "forward") await page.goForward({ timeout: 30_000, waitUntil: "domcontentloaded" });
        else if (action === "reload") await page.reload({ timeout: 45_000, waitUntil: "domcontentloaded" });
        else throw new Error("未知浏览器操作。");
        return res.json({ ok: true, url: page.url() });
    } catch (error) {
        return res.status(400).json({ error: error.message });
    }
});

app.get("/api/session/egress", requireRunning, async (req, res) => {
    let page;
    try {
        page = await runtime.context.newPage();
        await page.goto("https://api.ipify.org?format=json", { timeout: 30_000, waitUntil: "domcontentloaded" });
        const payload = JSON.parse(await page.locator("body").innerText());
        status = { ...status, egressIp: payload.ip || null };
        return res.json({ ip: status.egressIp, proxy: status.proxy });
    } catch (error) {
        return res.status(502).json({ error: `出口检测失败: ${error.message}` });
    } finally {
        await page?.close().catch(() => {});
    }
});

app.post("/api/vnc-ticket", requireRunning, (req, res) => {
    const ticket = crypto.randomBytes(24).toString("base64url");
    vncTickets.set(ticket, Date.now() + TICKET_TTL_MS);
    res.json({ expiresIn: TICKET_TTL_MS / 1000, ticket });
});

const publicDir = path.join(__dirname, "public");
app.use("/vendor/novnc", express.static(path.join(__dirname, "node_modules", "@novnc", "novnc")));
app.use("/vendor/lucide", express.static(path.join(__dirname, "node_modules", "lucide", "dist", "umd")));
app.use(express.static(publicDir));
app.get("*", (req, res) => res.sendFile(path.join(publicDir, "index.html")));

server.on("upgrade", (req, socket) => {
    const requestUrl = new URL(req.url, `http://${req.headers.host || "localhost"}`);
    if (requestUrl.pathname !== "/vnc" || status.state !== "running") {
        socket.write("HTTP/1.1 404 Not Found\r\nConnection: close\r\n\r\n");
        socket.destroy();
        return;
    }

    const ticket = requestUrl.searchParams.get("ticket") || "";
    const expiresAt = vncTickets.get(ticket);
    vncTickets.delete(ticket);
    if (!expiresAt || expiresAt < Date.now()) {
        socket.write("HTTP/1.1 401 Unauthorized\r\nConnection: close\r\n\r\n");
        socket.destroy();
        return;
    }

    const target = net.createConnection({ host: "127.0.0.1", port: WEBSOCKIFY_PORT });
    target.once("connect", () => {
        const headers = [
            "GET / HTTP/1.1",
            `Host: 127.0.0.1:${WEBSOCKIFY_PORT}`,
            "Upgrade: websocket",
            "Connection: Upgrade",
            `Sec-WebSocket-Key: ${req.headers["sec-websocket-key"]}`,
            `Sec-WebSocket-Version: ${req.headers["sec-websocket-version"] || "13"}`,
        ];
        for (const name of ["origin", "sec-websocket-protocol", "sec-websocket-extensions"]) {
            if (req.headers[name]) headers.push(`${name}: ${req.headers[name]}`);
        }
        target.write(`${headers.join("\r\n")}\r\n\r\n`);
        target.pipe(socket).pipe(target);
    });
    target.on("error", () => socket.destroy());
    socket.on("error", () => target.destroy());
});

setInterval(() => {
    const now = Date.now();
    for (const [ticket, expiresAt] of vncTickets) {
        if (expiresAt < now) vncTickets.delete(ticket);
    }
}, TICKET_TTL_MS).unref();

async function shutdown(signal) {
    log(`收到 ${signal}，正在关闭。`);
    server.close();
    await stopRuntime(signal);
    process.exit(0);
}

process.once("SIGINT", () => void shutdown("SIGINT"));
process.once("SIGTERM", () => void shutdown("SIGTERM"));

server.listen(PORT, "0.0.0.0", () => {
    log(`管理页面已启动: http://0.0.0.0:${PORT}`);
});
